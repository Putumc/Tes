command upload theme
sudo su

cd

cd /var/www/

git clone https://github.com/Putumc/Stellar

ls

cd enigma-pterodactyl-theme

mv pterodactyl.zip ../

unzip pterodactyl.zip